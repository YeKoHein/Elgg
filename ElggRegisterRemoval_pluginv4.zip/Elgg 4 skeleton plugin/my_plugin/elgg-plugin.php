<?php

return [
	'plugin' => [
		'name' => 'My Plugin',
		'version' => '4.2.0',
'dependencies' => [
			'profile' => [
				'position' => 'after',
				'must_be_active' => true,
			],
			'theme' => [
				'position' => 'after',
				'must_be_active' => false,
			],
		],
		'activate_on_install' => true,
	],
	
	'bootstrap' => \wZm\MyPlugin\Bootstrap::class,
];