<?php

return [
	'plugin' => [
		'name' => 'My Plugin',
		'version' => '4.0.0',
		'activate_on_install' => true,
	],
	
	'bootstrap' => \MyPlugin\Bootstrap::class,
];