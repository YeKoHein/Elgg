<?php

return [
	'bootstrap' => \MyPlugin\Bootstrap::class,
];